<?php
// =============================================
// VERİTABANI BAĞLANTI AYARLARI
// =============================================

$sunucu = ".";
$veritabani = "HastaneTakipSistemi";

$baglanti_ayarlari = array(
    "Database"               => $veritabani,
    "TrustServerCertificate" => true,
    "CharacterSet"           => "UTF-8",
    "LoginTimeout"           => 30
);

$conn = sqlsrv_connect($sunucu, $baglanti_ayarlari);

if ($conn === false) {
    die("
    <div style='font-family:sans-serif; padding:30px; background:#fee; color:#c00; border:1px solid #fcc; margin:20px; border-radius:8px;'>
        <h3>⚠️ Veritabanı Bağlantı Hatası</h3>
        <p>SQL Server'a bağlanılamadı. Lütfen şunları kontrol et:</p>
        <ul>
            <li>SQL Server çalışıyor mu?</li>
            <li>Veritabanı adı doğru mu? (<b>$veritabani</b>)</li>
        </ul>
        <pre>" . print_r(sqlsrv_errors(), true) . "</pre>
    </div>");
}
?>