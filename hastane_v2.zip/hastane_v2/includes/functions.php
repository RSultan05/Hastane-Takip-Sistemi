<?php
// =============================================
// OTURUM KONTROL VE YARDIMCI FONKSİYONLAR
// =============================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function girisKontrol() {
    if (!isset($_SESSION['kullanici_id'])) {
        header("Location: /hastane_v2/login.php");
        exit;
    }
}

function rolKontrol($izinliRoller) {
    if (!in_array($_SESSION['unvan'], $izinliRoller)) {
        header("Location: /hastane_v2/yetkisiz.php");
        exit;
    }
}

function tarihFormat($tarih, $format = 'd.m.Y') {
    if ($tarih instanceof DateTime) {
        return $tarih->format($format);
    }
    return $tarih ? date($format, strtotime($tarih)) : '-';
}

function saatFormat($tarih) {
    if ($tarih instanceof DateTime) {
        return $tarih->format('H:i');
    }
    return $tarih ? date('H:i', strtotime($tarih)) : '-';
}

function tcDogrula($tc) {
    if (strlen($tc) !== 11) return false;
    if ($tc[0] === '0') return false;
    if (!ctype_digit($tc)) return false;
    return true;
}

function telDogrula($tel) {
    $tel = preg_replace('/\D/', '', $tel);
    return strlen($tel) >= 10 && strlen($tel) <= 11;
}

function temizle($veri) {
    return htmlspecialchars(trim($veri ?? ''), ENT_QUOTES, 'UTF-8');
}
?>