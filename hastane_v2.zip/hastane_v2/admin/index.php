<?php
require_once '../includes/db.php';
require_once 'layout.php';

$toplam_hasta    = sqlsrv_fetch_array(sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Hastalar"))['c'];
$toplam_calisan  = sqlsrv_fetch_array(sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Kullanicilar WHERE aktif=1"))['c'];
$bugun_randevu   = sqlsrv_fetch_array(sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Randevular WHERE CAST(RandevuTarihi AS DATE)=CAST(GETDATE() AS DATE)"))['c'];
$bekleyen_tahlil = sqlsrv_fetch_array(sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Tahliller WHERE Durum='Bekliyor'"))['c'];

$son_randevular = sqlsrv_query($conn, "
    SELECT TOP 8 R.RandevuTarihi, R.Durum,
           H.Ad, H.Soyad,
           K.Ad AS DoktorAd, K.Soyad AS DoktorSoyad
    FROM Randevular R
    JOIN Hastalar H     ON R.HastaID  = H.HastaID
    JOIN Kullanicilar K ON R.DoktorID = K.KullaniciID
    WHERE CAST(R.RandevuTarihi AS DATE) = CAST(GETDATE() AS DATE)
    ORDER BY R.RandevuTarihi ASC
");
?>

<div class="ust-bar">
    <div class="ust-bar-baslik">Gösterge Paneli</div>
    <div class="ust-bar-sag">
        <span class="etiket etiket-mavi"><?= date('d.m.Y') ?></span>
    </div>
</div>

<div class="icerik">
    <div class="stat-grid stat-grid-4">
        <div class="stat-kart mavi">
            <div class="stat-etiket">Toplam Hasta</div>
            <div class="stat-deger"><?= number_format($toplam_hasta) ?></div>
        </div>
        <div class="stat-kart yesil">
            <div class="stat-etiket">Toplam Çalışan</div>
            <div class="stat-deger"><?= $toplam_calisan ?></div>
        </div>
    </div>

    <div class="panel">
        <div class="panel-baslik">
            <h3>Bugünkü Randevular</h3>
        </div>
        <?php
        $sayi = 0;
        while ($r = sqlsrv_fetch_array($son_randevular, SQLSRV_FETCH_ASSOC)):
            $sayi++;
            $renk = match($r['Durum']) {
                'Tamamlandı' => '#10b981',
                'İptal'      => '#ef4444',
                default      => '#3b82f6'
            };
        ?>
        <div class="randevu-satir">
            <span class="randevu-saat"><?= saatFormat($r['RandevuTarihi']) ?></span>
            <span class="randevu-nokta" style="background:<?= $renk ?>"></span>
            <span class="randevu-hasta"><?= temizle($r['Ad'].' '.$r['Soyad']) ?></span>
            <span class="randevu-doktor">Dr. <?= temizle($r['DoktorAd'].' '.$r['DoktorSoyad']) ?></span>
        </div>
        <?php endwhile; ?>
        <?php if ($sayi === 0): ?>
            <div style="padding:20px;text-align:center;color:#64748b;font-size:13px;">Bugün randevu bulunmuyor.</div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>