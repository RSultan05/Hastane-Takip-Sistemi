<?php
require_once __DIR__ . '/../includes/functions.php';
girisKontrol();
rolKontrol(['admin']);
$aktif_sayfa = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Paneli - Hastane Takip</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500&family=Syne:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/hastane_v2/assets/css/style.css">
</head>
<body>
<div class="sayfa-yapisi">
<div class="sidebar">
    <div class="sidebar-logo">
        <div class="ikon">🏥</div>
        <h2>Admin Paneli</h2>
        <span>Hastane Takip Sistemi</span>
    </div>
    <div class="menu-grup">
        <div class="menu-baslik">Kullanıcı Yönetimi</div>
        <a href="/hastane_v2/admin/kullanici_ekle.php" class="menu-link <?= $aktif_sayfa==='kullanici_ekle.php'?'aktif':'' ?>">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3"><circle cx="7" cy="5" r="3"/><path d="M1 14c0-3 2.5-5 6-5"/><path d="M12 10v4M10 12h4"/></svg>
            Kullanıcı Ekleme
        </a>
        <a href="/hastane_v2/admin/kullanici_listesi.php" class="menu-link <?= $aktif_sayfa==='kullanici_listesi.php'?'aktif':'' ?>">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3"><circle cx="5" cy="5" r="2.5"/><circle cx="11" cy="5" r="2.5"/><path d="M0 13c0-2.5 2-4 5-4"/><path d="M9 9.5c.6-.3 1.3-.5 2-.5 3 0 5 1.5 5 4"/></svg>
            Kullanıcı Yönetimi
        </a>
    </div>
    <div class="menu-grup">
        <div class="menu-baslik">Bölüm Yönetimi</div>
        <a href="/hastane_v2/admin/bolum_yonet.php" class="menu-link <?= $aktif_sayfa==='bolum_yonet.php'?'aktif':'' ?>">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3"><path d="M8 1L1 5v10h14V5z"/><path d="M6 15v-5h4v5"/></svg>
            Bölüm Yönetimi
        </a>
    </div>
    <div class="menu-grup">
        <div class="menu-baslik">Genel</div>
        <a href="/hastane_v2/admin/calisanlar.php" class="menu-link <?= $aktif_sayfa==='calisanlar.php'?'aktif':'' ?>">
            <svg viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="5" r="3"/><path d="M2 14c0-3.3 2.7-6 6-6s6 2.7 6 6"/></svg>
            Çalışanlar
        </a>
    </div>
    <div class="sidebar-alt">
        <div class="kullanici-bilgi">
            <strong><?= temizle($_SESSION['ad_soyad']) ?></strong><br>
            TC: <?= temizle($_SESSION['tc_kimlik']) ?><br>
            Admin
        </div>
        <a href="/hastane_v2/logout.php" class="cikis-link">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" width="15" height="15"><path d="M6 2H2v12h4M11 11l3-3-3-3M14 8H6"/></svg>
            Çıkış Yap
        </a>
    </div>
</div>
<div class="ana-icerik">