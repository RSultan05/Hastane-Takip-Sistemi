<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

$mesaj   = '';
$hatalar = [];
$duzenle = null;

// ---- SİLME ----
if (isset($_GET['sil'])) {
    $sil_id = (int)$_GET['sil'];
    if ($sil_id === (int)$_SESSION['kullanici_id']) {
        $mesaj = ['tip'=>'hata', 'metin'=>'Kendinizi silemezsiniz.'];
    } else {
        sqlsrv_query($conn, "DELETE FROM Kullanicilar WHERE KullaniciID=?", [$sil_id]);
        header("Location: kullanici_listesi.php?silindi=1"); exit;
    }
}
if (isset($_GET['silindi'])) $mesaj = ['tip'=>'basari', 'metin'=>'Kullanıcı silindi.'];

// ---- DÜZENLE ----
if (isset($_GET['duzenle'])) {
    $sorgu   = sqlsrv_query($conn, "SELECT * FROM Kullanicilar WHERE KullaniciID=?", [(int)$_GET['duzenle']]);
    $duzenle = sqlsrv_fetch_array($sorgu, SQLSRV_FETCH_ASSOC);
}

// ---- GÜNCELLEME ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guncelle'])) {
    $g_id  = (int)$_POST['kullanici_id'];
    $ad    = trim($_POST['ad']     ?? '');
    $soyad = trim($_POST['soyad']  ?? '');
    $sifre = trim($_POST['sifre']  ?? '');
    $unvan = trim($_POST['unvan']  ?? '');
    $bolum = !empty($_POST['bolum_id']) ? (int)$_POST['bolum_id'] : null;
    $tel   = trim($_POST['telefon'] ?? '');

    if (empty($ad))    $hatalar['ad']    = 'Ad boş olamaz.';
    if (empty($soyad)) $hatalar['soyad'] = 'Soyad boş olamaz.';
    if (!empty($tel) && !telDogrula($tel)) $hatalar['tel'] = 'Geçerli telefon girin.';

    if (empty($hatalar)) {
        if (!empty($sifre)) {
            $sql    = "UPDATE Kullanicilar SET Ad=?, Soyad=?, Sifre=?, Unvan=?, BolumID=?, Telefon=? WHERE KullaniciID=?";
            $params = [$ad, $soyad, $sifre, $unvan, $bolum, $tel ?: null, $g_id];
        } else {
            $sql    = "UPDATE Kullanicilar SET Ad=?, Soyad=?, Unvan=?, BolumID=?, Telefon=? WHERE KullaniciID=?";
            $params = [$ad, $soyad, $unvan, $bolum, $tel ?: null, $g_id];
        }
        $sorgu = sqlsrv_query($conn, $sql, $params);
        if ($sorgu) { $mesaj = ['tip'=>'basari','metin'=>'Kullanıcı güncellendi.']; $duzenle = null; }
        else        { $mesaj = ['tip'=>'hata',  'metin'=>'Güncelleme sırasında hata oluştu.']; }
    } else {
        $sorgu   = sqlsrv_query($conn, "SELECT * FROM Kullanicilar WHERE KullaniciID=?", [$g_id]);
        $duzenle = sqlsrv_fetch_array($sorgu, SQLSRV_FETCH_ASSOC);
    }
}

// Tüm kullanıcılar
$kullanicilar = sqlsrv_query($conn, "
    SELECT K.*, B.BolumAdi
    FROM Kullanicilar K
    LEFT JOIN Bolumler B ON K.BolumID = B.BolumID
    ORDER BY K.Unvan, K.Ad
");

// Bölümler
$bolumler = sqlsrv_query($conn, "SELECT BolumID, BolumAdi FROM Bolumler ORDER BY BolumAdi");
$bolum_listesi = [];
while ($b = sqlsrv_fetch_array($bolumler, SQLSRV_FETCH_ASSOC)) {
    $bolum_listesi[] = $b;
}
?>