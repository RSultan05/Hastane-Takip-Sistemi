<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

$mesaj   = '';
$hatalar = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tc    = trim($_POST['tc_kimlik'] ?? '');
    $ad    = trim($_POST['ad']        ?? '');
    $soyad = trim($_POST['soyad']     ?? '');
    $sifre = trim($_POST['sifre']     ?? '');
    $unvan = trim($_POST['unvan']     ?? '');
    $bolum = !empty($_POST['bolum_id']) ? (int)$_POST['bolum_id'] : null;
    $tel   = trim($_POST['telefon']   ?? '');

    if (!tcDogrula($tc))     $hatalar['tc']    = 'TC 11 hane olmalı ve 0 ile başlamamalı.';
    if (empty($ad))          $hatalar['ad']    = 'Ad boş bırakılamaz.';
    if (empty($soyad))       $hatalar['soyad'] = 'Soyad boş bırakılamaz.';
    if (strlen($sifre) < 4) $hatalar['sifre'] = 'Şifre en az 4 karakter olmalı.';
    if (!in_array($unvan, ['admin','doktor','sekreter'])) $hatalar['unvan'] = 'Geçerli bir unvan seçin.';
    if (!empty($tel) && !telDogrula($tel)) $hatalar['tel'] = 'Geçerli telefon numarası girin.';

    if (empty($hatalar['tc'])) {
        $kontrol = sqlsrv_query($conn, "SELECT KullaniciID FROM Kullanicilar WHERE TCKimlik=?", [$tc]);
        if (sqlsrv_fetch_array($kontrol)) $hatalar['tc'] = 'Bu TC kimlik zaten kayıtlı.';
    }

    if (empty($hatalar)) {
        $sql = "INSERT INTO Kullanicilar (TCKimlik, Ad, Soyad, Sifre, Unvan, BolumID, Telefon)
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $sorgu = sqlsrv_query($conn, $sql, [$tc, $ad, $soyad, $sifre, $unvan, $bolum, $tel ?: null]);
        $mesaj = $sorgu
            ? ['tip'=>'basari', 'metin'=>"$ad $soyad kullanıcısı eklendi."]
            : ['tip'=>'hata',   'metin'=>'Kayıt sırasında hata oluştu.'];
        if ($sorgu) $_POST = [];
    }
}

$bolumler = sqlsrv_query($conn, "SELECT BolumID, BolumAdi FROM Bolumler ORDER BY BolumAdi");
$bolum_listesi = [];
while ($b = sqlsrv_fetch_array($bolumler, SQLSRV_FETCH_ASSOC)) {
    $bolum_listesi[] = $b;
}
?>