<?php
require_once 'kullanici_ekle_islem.php';
require_once 'layout.php';
?>

<div class="ust-bar">
    <div class="ust-bar-baslik">Kullanıcı Ekleme</div>
</div>

<div class="icerik">

    <?php if ($mesaj): ?>
        <div class="bildirim bildirim-<?= $mesaj['tip']==='basari'?'basari':'hata' ?>">
            <?= $mesaj['tip']==='basari'?'✓':'✗' ?> <?= temizle($mesaj['metin']) ?>
        </div>
    <?php endif; ?>

    <div class="panel">
        <div class="panel-baslik"><h3>Yeni Kullanıcı Bilgileri</h3></div>
        <div class="panel-icerik">
            <form method="POST" action="">
                <div class="form-grid">

                    <div class="form-grup">
                        <label>TC Kimlik No *</label>
                        <input type="text" name="tc_kimlik" maxlength="11"
                               value="<?= temizle($_POST['tc_kimlik'] ?? '') ?>"
                               class="<?= isset($hatalar['tc'])?'hatali':'' ?>">
                        <?php if (isset($hatalar['tc'])): ?><span class="form-hata"><?= $hatalar['tc'] ?></span><?php endif; ?>
                    </div>

                    <div class="form-grup">
                        <label>Telefon</label>
                        <input type="text" name="telefon" placeholder="05xx..."
                               value="<?= temizle($_POST['telefon'] ?? '') ?>"
                               class="<?= isset($hatalar['tel'])?'hatali':'' ?>">
                        <?php if (isset($hatalar['tel'])): ?><span class="form-hata"><?= $hatalar['tel'] ?></span><?php endif; ?>
                    </div>

                    <div class="form-grup">
                        <label>Ad *</label>
                        <input type="text" name="ad" value="<?= temizle($_POST['ad'] ?? '') ?>"
                               class="<?= isset($hatalar['ad'])?'hatali':'' ?>">
                        <?php if (isset($hatalar['ad'])): ?><span class="form-hata"><?= $hatalar['ad'] ?></span><?php endif; ?>
                    </div>

                    <div class="form-grup">
                        <label>Soyad *</label>
                        <input type="text" name="soyad" value="<?= temizle($_POST['soyad'] ?? '') ?>"
                               class="<?= isset($hatalar['soyad'])?'hatali':'' ?>">
                        <?php if (isset($hatalar['soyad'])): ?><span class="form-hata"><?= $hatalar['soyad'] ?></span><?php endif; ?>
                    </div>

                    <div class="form-grup">
                        <label>Şifre *</label>
                        <input type="text" name="sifre" placeholder="En az 4 karakter"
                               value="<?= temizle($_POST['sifre'] ?? '') ?>"
                               class="<?= isset($hatalar['sifre'])?'hatali':'' ?>">
                        <?php if (isset($hatalar['sifre'])): ?><span class="form-hata"><?= $hatalar['sifre'] ?></span><?php endif; ?>
                    </div>

                    <div class="form-grup">
                        <label>Unvan *</label>
                        <select name="unvan" class="<?= isset($hatalar['unvan'])?'hatali':'' ?>">
                            <option value="">-- Seçin --</option>
                            <option value="admin"    <?= ($_POST['unvan']??'')==='admin'   ?'selected':'' ?>>Admin</option>
                            <option value="doktor"   <?= ($_POST['unvan']??'')==='doktor'  ?'selected':'' ?>>Doktor</option>
                            <option value="sekreter" <?= ($_POST['unvan']??'')==='sekreter'?'selected':'' ?>>Sekreter</option>
                        </select>
                        <?php if (isset($hatalar['unvan'])): ?><span class="form-hata"><?= $hatalar['unvan'] ?></span><?php endif; ?>
                    </div>

                    <div class="form-grup">
                        <label>Bölüm</label>
                        <select name="bolum_id">
                            <option value="">-- Seçin --</option>
                            <?php foreach ($bolum_listesi as $b): ?>
                            <option value="<?= $b['BolumID'] ?>"
                                <?= ($_POST['bolum_id']??'')==$b['BolumID']?'selected':'' ?>>
                                <?= temizle($b['BolumAdi']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                </div>
                <div class="form-aksiyonlar">
                    <button type="submit" class="btn btn-mavi">+ Kullanıcı Ekle</button>
                    <button type="reset" class="btn btn-gri">Temizle</button>
                </div>
            </form>
        </div>
    </div>

</div>

<?php require_once '../includes/footer.php'; ?>