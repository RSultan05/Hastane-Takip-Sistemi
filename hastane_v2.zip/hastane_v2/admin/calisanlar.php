<?php
require_once 'calisanlar_islem.php';
require_once 'layout.php';
?>

<div class="ust-bar"><div class="ust-bar-baslik">Çalışanlar</div></div>

<div class="icerik">

    <div class="stat-grid stat-grid-4">
        <div class="stat-kart mavi"><div class="stat-etiket">Toplam</div><div class="stat-deger"><?= $toplam ?></div></div>
        <div class="stat-kart yesil"><div class="stat-etiket">Doktor</div><div class="stat-deger"><?= $doktor ?></div></div>
        <div class="stat-kart sari"><div class="stat-etiket">Sekreter</div><div class="stat-deger"><?= $sekreter ?></div></div>
        <div class="stat-kart kirmizi"><div class="stat-etiket">Admin</div><div class="stat-deger"><?= $admin ?></div></div>
    </div>

    <div class="panel" style="margin-bottom:16px;">
        <div class="panel-baslik"><h3>Çalışan Ara</h3></div>
        <div class="panel-icerik">
            <form method="GET" action="">
                <div class="form-grid">
                    <div class="form-grup">
                        <label>Ad, Soyad veya TC</label>
                        <input type="text" name="ara" value="<?= temizle($arama) ?>" placeholder="Ad, soyad veya TC...">
                    </div>
                    <div class="form-grup">
                        <label>Unvan</label>
                        <select name="gorev">
                            <option value="">-- Tümü --</option>
                            <option value="admin"    <?= $gorev==='admin'   ?'selected':'' ?>>Admin</option>
                            <option value="doktor"   <?= $gorev==='doktor'  ?'selected':'' ?>>Doktor</option>
                            <option value="sekreter" <?= $gorev==='sekreter'?'selected':'' ?>>Sekreter</option>
                        </select>
                    </div>
                    <div class="form-grup">
                        <label>Bölüm</label>
                        <select name="bolum">
                            <option value="">-- Tümü --</option>
                            <?php foreach ($bolum_listesi as $b): ?>
                            <option value="<?= temizle($b['BolumAdi']) ?>" <?= $bolum===$b['BolumAdi']?'selected':'' ?>>
                                <?= temizle($b['BolumAdi']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-grup">
                        <label>Telefon</label>
                        <input type="text" name="tel" value="<?= temizle($tel) ?>">
                    </div>
                </div>
                <div class="form-aksiyonlar">
                    <button type="submit" class="btn btn-mavi">Ara</button>
                    <?php if ($arama||$gorev||$bolum||$tel): ?>
                    <a href="calisanlar.php" class="btn btn-gri">✕ Temizle</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <div class="panel">
        <div class="tablo-sarici">
            <table class="tablo">
                <thead><tr><th>#</th><th>Ad</th><th>Soyad</th><th>TC Kimlik</th><th>Unvan</th><th>Bölüm</th><th>Telefon</th></tr></thead>
                <tbody>
                <?php while ($c = sqlsrv_fetch_array($calisanlar, SQLSRV_FETCH_ASSOC)):
                    $renk = match($c['Unvan']) { 'admin'=>'etiket-kirmizi','doktor'=>'etiket-mavi','sekreter'=>'etiket-yesil',default=>'etiket-gri' };
                    $unvan_adi = match($c['Unvan']) { 'admin'=>'Admin','doktor'=>'Doktor','sekreter'=>'Sekreter',default=>$c['Unvan'] };
                ?>
                <tr>
                    <td class="soluk"><?= $c['KullaniciID'] ?></td>
                    <td><?= temizle($c['Ad']) ?></td>
                    <td><?= temizle($c['Soyad']) ?></td>
                    <td class="soluk"><?= temizle($c['TCKimlik']) ?></td>
                    <td><span class="etiket <?= $renk ?>"><?= $unvan_adi ?></span></td>
                    <td class="soluk"><?= temizle($c['BolumAdi'] ?? '-') ?></td>
                    <td class="soluk"><?= temizle($c['Telefon'] ?? '-') ?></td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once '../includes/footer.php'; ?>