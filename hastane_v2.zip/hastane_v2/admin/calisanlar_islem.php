<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

$toplam   = sqlsrv_fetch_array(sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Kullanicilar WHERE aktif=1"))['c'];
$doktor   = sqlsrv_fetch_array(sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Kullanicilar WHERE Unvan='doktor' AND aktif=1"))['c'];
$sekreter = sqlsrv_fetch_array(sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Kullanicilar WHERE Unvan='sekreter' AND aktif=1"))['c'];
$admin    = sqlsrv_fetch_array(sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Kullanicilar WHERE Unvan='admin' AND aktif=1"))['c'];

$arama = trim($_GET['ara']   ?? '');
$gorev = trim($_GET['gorev'] ?? '');
$bolum = trim($_GET['bolum'] ?? '');
$tel   = trim($_GET['tel']   ?? '');

$kosullar = ["K.aktif = 1"];
$params   = [];

if ($arama) {
    $kosullar[] = "(K.Ad LIKE ? OR K.Soyad LIKE ? OR K.TCKimlik LIKE ?)";
    $params = array_merge($params, ["%$arama%", "%$arama%", "%$arama%"]);
}
if ($gorev) { $kosullar[] = "K.Unvan=?"; $params[] = $gorev; }
if ($bolum) { $kosullar[] = "B.BolumAdi LIKE ?"; $params[] = "%$bolum%"; }
if ($tel)   { $kosullar[] = "K.Telefon LIKE ?";  $params[] = "%$tel%"; }

$where = implode(" AND ", $kosullar);
$calisanlar = sqlsrv_query($conn, "
    SELECT K.KullaniciID, K.Ad, K.Soyad, K.TCKimlik, K.Unvan, K.Telefon, B.BolumAdi
    FROM Kullanicilar K
    LEFT JOIN Bolumler B ON K.BolumID=B.BolumID
    WHERE $where ORDER BY K.Unvan, K.Ad
", $params ?: null);

$bolumler = sqlsrv_query($conn, "SELECT BolumID, BolumAdi FROM Bolumler ORDER BY BolumAdi");
$bolum_listesi = [];
while ($b = sqlsrv_fetch_array($bolumler, SQLSRV_FETCH_ASSOC)) $bolum_listesi[] = $b;
?>