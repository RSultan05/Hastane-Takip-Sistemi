<?php
require_once '../includes/db.php';
require_once 'layout.php';
$doktor_id = $_SESSION['kullanici_id'];
$mesaj     = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $randevu_id = (int)$_POST['randevu_id'];
    $sikayet    = trim($_POST['sikayet']    ?? '');
    $tani       = trim($_POST['tani']       ?? '');
    $recete     = trim($_POST['recete']     ?? '');

    $kontrol = sqlsrv_query($conn, "SELECT HastaID FROM Randevular WHERE RandevuID=? AND DoktorID=?", [$randevu_id, $doktor_id]);
    $randevu = sqlsrv_fetch_array($kontrol, SQLSRV_FETCH_ASSOC);

    if (!$randevu) {
        $mesaj = ['tip'=>'hata','metin'=>'Geçersiz randevu.'];
    } else {
        $hasta_id = $randevu['HastaID'];
        $sorgu = sqlsrv_query($conn,
            "INSERT INTO Muayeneler (RandevuID, HastaID, DoktorID, Sikayet, Tani, Recete)
             VALUES (?, ?, ?, ?, ?, ?)",
            [$randevu_id, $hasta_id, $doktor_id, $sikayet, $tani, $recete]
        );
        if ($sorgu) {
            sqlsrv_query($conn, "UPDATE Randevular SET Durum='Tamamlandı' WHERE RandevuID=?", [$randevu_id]);
            $mesaj = ['tip'=>'basari','metin'=>'Muayene kaydedildi ve randevu tamamlandı olarak işaretlendi.'];
            $_POST = [];
        } else {
            $mesaj = ['tip'=>'hata','metin'=>'Kayıt sırasında hata oluştu.'];
        }
    }
}

// Bekleyen randevular
$randevular = sqlsrv_query($conn, "
    SELECT R.RandevuID, R.RandevuTarihi, H.HastaID, H.Ad, H.Soyad
    FROM Randevular R
    JOIN Hastalar H ON R.HastaID=H.HastaID
    WHERE R.DoktorID=? AND R.Durum='Bekliyor'
    ORDER BY R.RandevuTarihi DESC
", [$doktor_id]);

$randevu_listesi = [];
while ($r = sqlsrv_fetch_array($randevular, SQLSRV_FETCH_ASSOC)) {
    $randevu_listesi[] = $r;
}
?>

<div class="ust-bar"><div class="ust-bar-baslik">Muayene Sonucu</div></div>
<div class="icerik">

    <?php if ($mesaj): ?>
        <div class="bildirim bildirim-<?= $mesaj['tip']==='basari'?'basari':'hata' ?>">
            <?= $mesaj['tip']==='basari'?'✓':'✗' ?> <?= temizle($mesaj['metin']) ?>
        </div>
    <?php endif; ?>

    <div class="panel">
        <div class="panel-baslik"><h3>Muayene Formu</h3></div>
        <div class="panel-icerik">
            <form method="POST" action="">
                <div class="form-grid">

                    <div class="form-grup tam">
                        <label>Randevu Seç (Bekleyen) *</label>
                        <select name="randevu_id" required onchange="randevuSec(this)">
                            <option value="">-- Randevu seçin --</option>
                            <?php foreach ($randevu_listesi as $r):
                                $tarih = tarihFormat($r['RandevuTarihi'],'d.m.Y H:i');
                            ?>
                            <option value="<?= $r['RandevuID'] ?>"
                                    data-hasta="<?= $r['HastaID'] ?>"
                                    <?= ($_POST['randevu_id']??'')==$r['RandevuID']?'selected':'' ?>>
                                <?= temizle($tarih.' — '.$r['Ad'].' '.$r['Soyad']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (empty($randevu_listesi)): ?>
                            <span class="form-hata">Bekleyen randevunuz bulunmuyor.</span>
                        <?php endif; ?>
                    </div>

                    <input type="hidden" name="hasta_id" id="hasta_id_hidden" value="<?= (int)($_POST['hasta_id']??0) ?>">

                    <div class="form-grup tam">
                        <label>Şikayet</label>
                        <textarea name="sikayet" rows="3"><?= temizle($_POST['sikayet']??'') ?></textarea>
                    </div>

                    <div class="form-grup tam">
                        <label>Tanı</label>
                        <textarea name="tani" rows="3"><?= temizle($_POST['tani']??'') ?></textarea>
                    </div>

                    <div class="form-grup tam">
                        <label>Reçete</label>
                        <textarea name="recete" rows="3"><?= temizle($_POST['recete']??'') ?></textarea>
                    </div>

                </div>
                <div class="form-aksiyonlar">
                    <button type="submit" class="btn btn-mavi">Muayene Kaydet</button>
                </div>
            </form>
        </div>
    </div>

</div>

<script>
function randevuSec(sel) {
    var opt = sel.options[sel.selectedIndex];
    document.getElementById('hasta_id_hidden').value = opt.dataset.hasta || '';
}
</script>

<?php require_once '../includes/footer.php'; ?>