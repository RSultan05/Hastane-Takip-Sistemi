<?php
require_once '../includes/db.php';
require_once 'layout.php';
$doktor_id = $_SESSION['kullanici_id'];
if (isset($_GET['tamamla'])) {
    sqlsrv_query($conn, "UPDATE Randevular SET Durum='Tamamlandı' WHERE RandevuID=? AND DoktorID=?", [(int)$_GET['tamamla'], $doktor_id]);
    header("Location: randevular.php?ok=1"); exit;
}
if (isset($_GET['ok'])) $mesaj = ['tip'=>'basari','metin'=>'Randevu tamamlandı olarak işaretlendi.'];
$randevular = sqlsrv_query($conn, "
    SELECT R.RandevuID, R.RandevuTarihi, R.Durum, H.Ad, H.Soyad, H.TCKimlik, H.KanGrubu, B.BolumAdi
    FROM Randevular R
    JOIN Hastalar H ON R.HastaID=H.HastaID
    JOIN Bolumler B ON R.BolumID=B.BolumID
    WHERE R.DoktorID=? ORDER BY R.RandevuTarihi DESC
", [$doktor_id]);
?>
<div class="ust-bar"><div class="ust-bar-baslik">Randevularım</div></div>
<div class="icerik">
    <?php if (isset($mesaj)): ?><div class="bildirim bildirim-basari">✓ <?= temizle($mesaj['metin']) ?></div><?php endif; ?>
    <div class="panel"><div class="tablo-sarici">
        <table class="tablo">
            <thead><tr><th>#</th><th>Ad</th><th>Soyad</th><th>TC</th><th>Kan Grubu</th><th>Bölüm</th><th>Tarih/Saat</th><th>Durum</th><th>İşlem</th></tr></thead>
            <tbody>
            <?php while($r=sqlsrv_fetch_array($randevular,SQLSRV_FETCH_ASSOC)):
                $renk=match($r['Durum']){'Tamamlandı'=>'etiket-yesil','İptal'=>'etiket-kirmizi',default=>'etiket-sari'}; ?>
            <tr>
                <td class="soluk"><?= $r['RandevuID'] ?></td>
                <td><?= temizle($r['Ad']) ?></td>
                <td><?= temizle($r['Soyad']) ?></td>
                <td class="soluk"><?= temizle($r['TCKimlik']) ?></td>
                <td><span class="etiket etiket-mavi"><?= temizle($r['KanGrubu']??'-') ?></span></td>
                <td class="soluk"><?= temizle($r['BolumAdi']) ?></td>
                <td class="soluk"><?= tarihFormat($r['RandevuTarihi'],'d.m.Y H:i') ?></td>
                <td><span class="etiket <?= $renk ?>"><?= temizle($r['Durum']) ?></span></td>
                <td><?php if($r['Durum']==='Bekliyor'): ?>
                    <a href="?tamamla=<?= $r['RandevuID'] ?>" class="btn btn-yesil btn-kucuk" onclick="return confirm('Tamamlandı işaretlensin mi?')">✓</a>
                <?php endif; ?></td>
            </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div></div>
</div>
<?php require_once '../includes/footer.php'; ?>