<?php
require_once '../includes/db.php';
require_once 'layout.php';
$doktor_id   = $_SESSION['kullanici_id'];
$hasta_id    = isset($_GET['hasta_id']) ? (int)$_GET['hasta_id'] : null;
$hasta_bilgi = null;

if ($hasta_id) {
    $kontrol = sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Randevular WHERE HastaID=? AND DoktorID=?", [$hasta_id, $doktor_id]);
    if (sqlsrv_fetch_array($kontrol)['c'] > 0) {
        $sorgu = sqlsrv_query($conn, "SELECT * FROM Hastalar WHERE HastaID=?", [$hasta_id]);
        $hasta_bilgi = sqlsrv_fetch_array($sorgu, SQLSRV_FETCH_ASSOC);
        $tahliller   = sqlsrv_query($conn, "SELECT * FROM Tahliller WHERE HastaID=? ORDER BY IstekTarihi DESC", [$hasta_id]);
        $randevular  = sqlsrv_query($conn, "SELECT R.*, B.BolumAdi FROM Randevular R JOIN Bolumler B ON R.BolumID=B.BolumID WHERE R.HastaID=? AND R.DoktorID=? ORDER BY R.RandevuTarihi DESC", [$hasta_id, $doktor_id]);
    } else {
        $hata = "Bu ID'ye sahip hasta bulunamadı veya bu hastanızla randevunuz yok.";
    }
}

$hasta_listesi = sqlsrv_query($conn, "
    SELECT DISTINCT H.HastaID, H.Ad, H.Soyad, H.TCKimlik, H.KanGrubu, H.Telefon
    FROM Hastalar H JOIN Randevular R ON H.HastaID=R.HastaID
    WHERE R.DoktorID=? ORDER BY H.Ad
", [$doktor_id]);
?>

<div class="ust-bar"><div class="ust-bar-baslik">Hastalarım</div></div>
<div class="icerik">

    <div class="panel" style="max-width:400px;margin-bottom:20px;">
        <div class="panel-baslik"><h3>Hasta ID ile Ara</h3></div>
        <div class="panel-icerik">
            <form method="GET" style="display:flex;gap:8px;">
                <input type="number" name="hasta_id" placeholder="Hasta ID..." value="<?= $hasta_id??'' ?>"
                       style="flex:1;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:7px;padding:9px 12px;color:#f8fafc;font-family:'DM Sans',sans-serif;font-size:13px;outline:none;">
                <button type="submit" class="btn btn-mavi">Ara</button>
                <?php if($hasta_id): ?><a href="hastalar.php" class="btn btn-gri">✕</a><?php endif; ?>
            </form>
        </div>
    </div>

    <?php if (isset($hata)): ?><div class="bildirim bildirim-hata">✗ <?= temizle($hata) ?></div><?php endif; ?>

    <?php if ($hasta_bilgi): ?>
    <div class="panel" style="margin-bottom:20px;">
        <div class="panel-baslik"><h3>Hasta Bilgileri — #<?= $hasta_bilgi['HastaID'] ?></h3></div>
        <div class="panel-icerik">
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;">
                <div><div style="font-size:11px;color:#64748b;margin-bottom:3px;">Ad</div><div><?= temizle($hasta_bilgi['Ad']) ?></div></div>
                <div><div style="font-size:11px;color:#64748b;margin-bottom:3px;">Soyad</div><div><?= temizle($hasta_bilgi['Soyad']) ?></div></div>
                <div><div style="font-size:11px;color:#64748b;margin-bottom:3px;">TC Kimlik</div><div><?= temizle($hasta_bilgi['TCKimlik']) ?></div></div>
                <div><div style="font-size:11px;color:#64748b;margin-bottom:3px;">Kan Grubu</div><div><span class="etiket etiket-kirmizi"><?= temizle($hasta_bilgi['KanGrubu']??'-') ?></span></div></div>
                <div><div style="font-size:11px;color:#64748b;margin-bottom:3px;">Cinsiyet</div><div><?= temizle($hasta_bilgi['Cinsiyet']??'-') ?></div></div>
                <div><div style="font-size:11px;color:#64748b;margin-bottom:3px;">Telefon</div><div><?= temizle($hasta_bilgi['Telefon']??'-') ?></div></div>
                <div><div style="font-size:11px;color:#64748b;margin-bottom:3px;">Doğum Tarihi</div><div><?= tarihFormat($hasta_bilgi['DogumTarihi']) ?></div></div>
            </div>
        </div>
    </div>

    <div class="panel" style="margin-bottom:20px;">
        <div class="panel-baslik"><h3>Tahlil Sonuçları</h3></div>
        <div class="tablo-sarici"><table class="tablo">
            <thead><tr><th>Tahlil Türü</th><th>İstek Tarihi</th><th>Sonuç</th><th>Durum</th></tr></thead>
            <tbody>
            <?php $t_sayi=0; while($t=sqlsrv_fetch_array($tahliller,SQLSRV_FETCH_ASSOC)): $t_sayi++; ?>
            <tr>
                <td><?= temizle($t['TahlilTuru']) ?></td>
                <td class="soluk"><?= tarihFormat($t['IstekTarihi']) ?></td>
                <td class="soluk"><?= $t['Sonuc']?temizle(substr($t['Sonuc'],0,50)):'—' ?></td>
                <td><span class="etiket <?= $t['Durum']==='Tamamlandı'?'etiket-yesil':'etiket-sari' ?>"><?= $t['Durum'] ?></span></td>
            </tr>
            <?php endwhile; if($t_sayi===0): ?><tr><td colspan="4" style="text-align:center;color:#64748b;padding:16px;">Tahlil kaydı yok.</td></tr><?php endif; ?>
            </tbody>
        </table></div>
    </div>

    <div class="panel">
        <div class="panel-baslik"><h3>Randevu Geçmişi</h3></div>
        <div class="tablo-sarici"><table class="tablo">
            <thead><tr><th>Tarih</th><th>Bölüm</th><th>Durum</th></tr></thead>
            <tbody>
            <?php while($rv=sqlsrv_fetch_array($randevular,SQLSRV_FETCH_ASSOC)):
                $rv_renk=match($rv['Durum']){'Tamamlandı'=>'etiket-yesil','İptal'=>'etiket-kirmizi',default=>'etiket-sari'}; ?>
            <tr>
                <td class="soluk"><?= tarihFormat($rv['RandevuTarihi'],'d.m.Y H:i') ?></td>
                <td><?= temizle($rv['BolumAdi']) ?></td>
                <td><span class="etiket <?= $rv_renk ?>"><?= temizle($rv['Durum']) ?></span></td>
            </tr>
            <?php endwhile; ?>
            </tbody>
        </table></div>
    </div>

    <?php else: ?>
    <div class="sayfa-baslik"><h2>Tüm Hastalarım</h2></div>
    <div class="panel"><div class="tablo-sarici">
        <table class="tablo">
            <thead><tr><th>ID</th><th>Ad</th><th>Soyad</th><th>TC Kimlik</th><th>Kan Grubu</th><th>Telefon</th><th>Detay</th></tr></thead>
            <tbody>
            <?php while($h=sqlsrv_fetch_array($hasta_listesi,SQLSRV_FETCH_ASSOC)): ?>
            <tr>
                <td><span class="etiket etiket-mavi">#<?= $h['HastaID'] ?></span></td>
                <td><?= temizle($h['Ad']) ?></td>
                <td><?= temizle($h['Soyad']) ?></td>
                <td class="soluk"><?= temizle($h['TCKimlik']) ?></td>
                <td><span class="etiket etiket-kirmizi"><?= temizle($h['KanGrubu']??'-') ?></span></td>
                <td class="soluk"><?= temizle($h['Telefon']??'-') ?></td>
                <td><a href="?hasta_id=<?= $h['HastaID'] ?>" class="btn btn-mavi btn-kucuk">Görüntüle</a></td>
            </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div></div>
    <?php endif; ?>
</div>
<?php require_once '../includes/footer.php'; ?>