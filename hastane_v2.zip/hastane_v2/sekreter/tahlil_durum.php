<?php

require_once '../includes/db.php';
require_once 'layout.php';

$arama = trim($_GET['ara'] ?? '');

$params = [];
$sql = "
    SELECT T.TahlilID, T.TahlilTuru, T.IstekTarihi, T.Sonuc, T.SonucTarihi, T.Durum,
           H.HastaID, H.Ad + ' ' + H.Soyad as hasta_adi,
           K.Ad + ' ' + K.Soyad as doktor_adi
    FROM Tahliller T
    JOIN Hastalar H     ON T.HastaID  = H.HastaID
    JOIN Kullanicilar K ON T.DoktorID = K.KullaniciID
";
if ($arama) {
    $sql .= " WHERE H.Ad LIKE ? OR H.Soyad LIKE ? OR T.TahlilTuru LIKE ?";
    $params = ["%$arama%", "%$arama%", "%$arama%"];
}
$sql .= " ORDER BY T.IstekTarihi DESC";
$tahliller = sqlsrv_query($conn, $sql, $params ?: null);

$bekleyen   = sqlsrv_fetch_array(sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Tahliller WHERE Durum='Bekliyor'"))['c'];
$tamamlanan = sqlsrv_fetch_array(sqlsrv_query($conn, "SELECT COUNT(*) as c FROM Tahliller WHERE Durum='Tamamlandı'"))['c'];
?>

<div class="ust-bar">
    <div class="ust-bar-baslik">Tahlil Durumu</div>
</div>

<div class="icerik">

    <div class="stat-grid stat-grid-2" style="max-width:400px;">
        <div class="stat-kart sari">
            <div class="stat-etiket">Bekleyen</div>
            <div class="stat-deger"><?= $bekleyen ?></div>
        </div>
        <div class="stat-kart yesil">
            <div class="stat-etiket">Tamamlanan</div>
            <div class="stat-deger"><?= $tamamlanan ?></div>
        </div>
    </div>

    <form method="GET" class="arama-form">
        <input type="text" name="ara" value="<?= temizle($arama) ?>"
               placeholder="Hasta adı veya tahlil türü ara...">
        <button type="submit" class="btn btn-mavi">Ara</button>
        <?php if ($arama): ?>
            <a href="tahlil_durum.php" class="btn btn-gri">✕ Temizle</a>
        <?php endif; ?>
    </form>

    <div class="panel">
        <div class="tablo-sarici">
            <table class="tablo">
                <thead>
                    <tr><th>#</th><th>Hasta</th><th>Doktor</th><th>Tahlil Türü</th><th>İstek Tarihi</th><th>Sonuç</th><th>Durum</th></tr>
                </thead>
                <tbody>
                <?php while ($t = sqlsrv_fetch_array($tahliller, SQLSRV_FETCH_ASSOC)):
                    $renk = $t['Durum'] === 'Tamamlandı' ? 'etiket-yesil' : 'etiket-sari';
                ?>
                <tr>
                    <td class="soluk"><?= $t['TahlilID'] ?></td>
                    <td>
                        <span class="etiket etiket-mavi" style="margin-right:4px;">#<?= $t['HastaID'] ?></span>
                        <?= temizle($t['hasta_adi']) ?>
                    </td>
                    <td class="soluk">Dr. <?= temizle($t['doktor_adi']) ?></td>
                    <td><?= temizle($t['TahlilTuru']) ?></td>
                    <td class="soluk"><?= tarihFormat($t['IstekTarihi']) ?></td>
                    <td class="soluk"><?= $t['Sonuc'] ? temizle(substr($t['Sonuc'],0,40)).'...' : '—' ?></td>
                    <td><span class="etiket <?= $renk ?>"><?= temizle($t['Durum']) ?></span></td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once '../includes/footer.php'; ?>