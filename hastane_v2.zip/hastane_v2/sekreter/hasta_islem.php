<?php
require_once '../includes/db.php';
require_once 'layout.php';
$mesaj=$hatalar=[];

if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['kaydet'])){
    $tc=trim($_POST['tc_kimlik']??'');$ad=trim($_POST['ad']??'');$soyad=trim($_POST['soyad']??'');
    $dogum=trim($_POST['dogum_tarihi']??'');$cinsiyet=trim($_POST['cinsiyet']??'');
    $kan=trim($_POST['kan_grubu']??'');$tel=trim($_POST['telefon']??'');
    if(!tcDogrula($tc))$hatalar['tc']='TC 11 hane olmalı ve 0 ile başlamamalı.';
    if(empty($ad))$hatalar['ad']='Ad boş olamaz.';
    if(empty($soyad))$hatalar['soyad']='Soyad boş olamaz.';
    if(!empty($tel)&&!telDogrula($tel))$hatalar['tel']='Geçerli telefon numarası girin.';
    if(empty($hatalar['tc'])){
        $k=sqlsrv_query($conn,"SELECT HastaID FROM Hastalar WHERE TCKimlik=?",[$tc]);
        if(sqlsrv_fetch_array($k))$hatalar['tc']='Bu TC kimlik zaten kayıtlı.';
    }
    if(empty($hatalar)){
        $s=sqlsrv_query($conn,"INSERT INTO Hastalar(TCKimlik,Ad,Soyad,DogumTarihi,Cinsiyet,Telefon,KanGrubu) VALUES(?,?,?,?,?,?,?)",
            [$tc,$ad,$soyad,$dogum?:null,$cinsiyet,$tel?:null,$kan]);
        $mesaj=$s?['tip'=>'basari','metin'=>"$ad $soyad kaydedildi."]:['tip'=>'hata','metin'=>'Hata oluştu.'];
        if($s)$_POST=[];
    }
}
if(isset($_GET['sil'])){
    $sid=(int)$_GET['sil'];
    $k=sqlsrv_query($conn,"SELECT COUNT(*) as c FROM Randevular WHERE HastaID=?",[$sid]);
    if(sqlsrv_fetch_array($k)['c']>0){$mesaj=['tip'=>'hata','metin'=>'Randevusu var. Önce randevuları silin.'];}
    else{sqlsrv_query($conn,"DELETE FROM Hastalar WHERE HastaID=?",[$sid]);header("Location: hasta_islem.php?silindi=1");exit;}
}
if(isset($_GET['silindi']))$mesaj=['tip'=>'basari','metin'=>'Hasta silindi.'];
$hastalar=sqlsrv_query($conn,"SELECT TOP 20 HastaID,Ad,Soyad,TCKimlik,KanGrubu,KayitTarihi FROM Hastalar ORDER BY KayitTarihi DESC");
?>
<div class="ust-bar"><div class="ust-bar-baslik">Hasta Kaydı / Silme</div></div>
<div class="icerik">
    <?php if($mesaj): ?><div class="bildirim bildirim-<?= $mesaj['tip']==='basari'?'basari':'hata' ?>"><?= $mesaj['tip']==='basari'?'✓':'✗' ?> <?= temizle($mesaj['metin']) ?></div><?php endif; ?>
    <div class="panel" style="margin-bottom:24px;">
        <div class="panel-baslik"><h3>Yeni Hasta Kaydı</h3></div>
        <div class="panel-icerik">
            <form method="POST">
                <div class="form-grid">
                    <div class="form-grup"><label>TC Kimlik No *</label>
                        <input type="text" name="tc_kimlik" maxlength="11" value="<?= temizle($_POST['tc_kimlik']??'') ?>" class="<?= isset($hatalar['tc'])?'hatali':'' ?>">
                        <?php if(isset($hatalar['tc'])): ?><span class="form-hata"><?= $hatalar['tc'] ?></span><?php endif; ?></div>
                    <div class="form-grup"><label>Telefon</label>
                        <input type="text" name="telefon" placeholder="05xx..." value="<?= temizle($_POST['telefon']??'') ?>" oninput="this.value=this.value.replace(/\D/g,'')">
                        <?php if(isset($hatalar['tel'])): ?><span class="form-hata"><?= $hatalar['tel'] ?></span><?php endif; ?></div>
                    <div class="form-grup"><label>Ad *</label>
                        <input type="text" name="ad" value="<?= temizle($_POST['ad']??'') ?>" class="<?= isset($hatalar['ad'])?'hatali':'' ?>">
                        <?php if(isset($hatalar['ad'])): ?><span class="form-hata"><?= $hatalar['ad'] ?></span><?php endif; ?></div>
                    <div class="form-grup"><label>Soyad *</label>
                        <input type="text" name="soyad" value="<?= temizle($_POST['soyad']??'') ?>" class="<?= isset($hatalar['soyad'])?'hatali':'' ?>">
                        <?php if(isset($hatalar['soyad'])): ?><span class="form-hata"><?= $hatalar['soyad'] ?></span><?php endif; ?></div>
                    <div class="form-grup"><label>Doğum Tarihi</label><input type="date" name="dogum_tarihi" value="<?= temizle($_POST['dogum_tarihi']??'') ?>"></div>
                    <div class="form-grup"><label>Cinsiyet</label>
                        <select name="cinsiyet"><option value="">-- Seçin --</option>
                            <option value="E" <?= ($_POST['cinsiyet']??'')==='E'?'selected':'' ?>>Erkek</option>
                            <option value="K" <?= ($_POST['cinsiyet']??'')==='K'?'selected':'' ?>>Kadın</option>
                        </select></div>
                    <div class="form-grup"><label>Kan Grubu</label>
                        <select name="kan_grubu"><option value="">-- Seçin --</option>
                            <?php foreach(['A+','A-','B+','B-','AB+','AB-','0+','0-'] as $kg): ?>
                            <option value="<?= $kg ?>" <?= ($_POST['kan_grubu']??'')===$kg?'selected':'' ?>><?= $kg ?></option>
                            <?php endforeach; ?></select></div>
                </div>
                <div class="form-aksiyonlar">
                    <button type="submit" name="kaydet" class="btn btn-mavi">+ Hasta Kaydet</button>
                    <button type="reset" class="btn btn-gri">Temizle</button>
                </div>
            </form>
        </div>
    </div>
    <div class="sayfa-baslik"><h2>Son Kayıtlar</h2><a href="/hastane_v2/sekreter/hasta_listesi.php" class="btn btn-gri">Tüm Liste →</a></div>
    <div class="panel"><div class="tablo-sarici"><table class="tablo">
        <thead><tr><th>ID</th><th>Ad</th><th>Soyad</th><th>TC Kimlik</th><th>Kan Grubu</th><th>Kayıt Tarihi</th><th>İşlem</th></tr></thead>
        <tbody>
        <?php while($h=sqlsrv_fetch_array($hastalar,SQLSRV_FETCH_ASSOC)): ?>
        <tr>
            <td><span class="etiket etiket-mavi">#<?= $h['HastaID'] ?></span></td>
            <td><?= temizle($h['Ad']) ?></td><td><?= temizle($h['Soyad']) ?></td>
            <td class="soluk"><?= temizle($h['TCKimlik']) ?></td>
            <td><span class="etiket etiket-kirmizi"><?= temizle($h['KanGrubu']??'-') ?></span></td>
            <td class="soluk"><?= tarihFormat($h['KayitTarihi']) ?></td>
            <td><a href="?sil=<?= $h['HastaID'] ?>" class="btn btn-kirmizi btn-kucuk" onclick="return confirm('<?= temizle($h['Ad'].' '.$h['Soyad']) ?> silinsin mi?')">🗑 Sil</a></td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table></div></div>
</div>
<?php require_once '../includes/footer.php'; ?>