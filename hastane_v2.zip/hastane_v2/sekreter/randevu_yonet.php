<?php
require_once '../includes/db.php';
require_once 'layout.php';

$mesaj   = null;
$duzenle = null;


if (isset($_GET['sil'])) {
    sqlsrv_query($conn, "DELETE FROM Randevular WHERE RandevuID=?", [(int)$_GET['sil']]);
    header("Location: randevu_yonet.php?silindi=1"); exit;
}
if (isset($_GET['silindi'])) {
    $mesaj = ['tip' => 'basari', 'metin' => 'Randevu silindi.'];
}


if (isset($_GET['duzenle'])) {
    $sorgu = sqlsrv_query($conn,
        "SELECT R.*, H.Ad, H.Soyad
         FROM Randevular R JOIN Hastalar H ON R.HastaID=H.HastaID
         WHERE R.RandevuID=?", [(int)$_GET['duzenle']]);
    $duzenle = sqlsrv_fetch_array($sorgu, SQLSRV_FETCH_ASSOC);
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guncelle'])) {
    $rid   = (int)$_POST['randevu_id'];
    $tarih = trim($_POST['randevu_tarihi'] ?? '');
    $durum = trim($_POST['durum'] ?? '');

    $sorgu = sqlsrv_query($conn,
        "UPDATE Randevular SET RandevuTarihi=?, Durum=? WHERE RandevuID=?",
        [$tarih, $durum, $rid]
    );
    $mesaj = $sorgu
        ? ['tip' => 'basari', 'metin' => 'Randevu güncellendi.']
        : ['tip' => 'hata',   'metin' => 'Güncelleme sırasında hata oluştu.'];
    $duzenle = null;
}


$randevular = sqlsrv_query($conn, "
    SELECT R.RandevuID, R.RandevuTarihi, R.Durum,
           H.Ad, H.Soyad, H.HastaID,
           K.Ad AS doktor_ad, K.Soyad AS doktor_soyad,
           B.BolumAdi
    FROM Randevular R
    JOIN Hastalar H     ON R.HastaID  = H.HastaID
    JOIN Kullanicilar K ON R.DoktorID = K.KullaniciID
    JOIN Bolumler B     ON R.BolumID  = B.BolumID
    ORDER BY R.RandevuTarihi DESC
");
?>

<div class="ust-bar"><div class="ust-bar-baslik">Randevu Yönetimi</div></div>

<div class="icerik">

    <?php if ($mesaj): ?>
        <div class="bildirim bildirim-<?= $mesaj['tip'] === 'basari' ? 'basari' : 'hata' ?>">
            <?= $mesaj['tip'] === 'basari' ? '✓' : '✗' ?>
            <?= temizle($mesaj['metin']) ?>
        </div>
    <?php endif; ?>

    <?php if ($duzenle): ?>
    <div class="panel" style="margin-bottom:20px; border:1px solid rgba(245,158,11,0.3);">
        <div class="panel-baslik">
            <h3>Randevu Güncelle — <?= temizle($duzenle['Ad'].' '.$duzenle['Soyad']) ?></h3>
            <a href="randevu_yonet.php">✕ İptal</a>
        </div>
        <div class="panel-icerik">
            <form method="POST" action="">
                <input type="hidden" name="randevu_id" value="<?= $duzenle['RandevuID'] ?>">
                <div class="form-grid">
                    <div class="form-grup">
                        <label>Tarih ve Saat</label>
                        <input type="datetime-local" name="randevu_tarihi"
                               value="<?= tarihFormat($duzenle['RandevuTarihi'], 'Y-m-d\TH:i') ?>">
                    </div>
                    <div class="form-grup">
                        <label>Durum</label>
                        <select name="durum">
                            <option value="Bekliyor"   <?= $duzenle['Durum']==='Bekliyor'   ? 'selected':'' ?>>Bekliyor</option>
                            <option value="Tamamlandı" <?= $duzenle['Durum']==='Tamamlandı' ? 'selected':'' ?>>Tamamlandı</option>
                            <option value="İptal"      <?= $duzenle['Durum']==='İptal'      ? 'selected':'' ?>>İptal</option>
                        </select>
                    </div>
                </div>
                <div class="form-aksiyonlar">
                    <button type="submit" name="guncelle" class="btn btn-mavi">Güncelle</button>
                    <a href="randevu_yonet.php" class="btn btn-gri">İptal</a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>


    <div class="panel">
        <div class="tablo-sarici">
            <table class="tablo">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Hasta Ad</th>
                        <th>Hasta Soyad</th>
                        <th>Doktor Ad</th>
                        <th>Doktor Soyad</th>
                        <th>Bölüm</th>
                        <th>Tarih/Saat</th>
                        <th>Durum</th>
                        <th>İşlem</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($r = sqlsrv_fetch_array($randevular, SQLSRV_FETCH_ASSOC)):
                    $renk = match($r['Durum']) {
                        'Tamamlandı' => 'etiket-yesil',
                        'İptal'      => 'etiket-kirmizi',
                        default      => 'etiket-sari'
                    };
                ?>
                <tr>
                    <td class="soluk"><?= $r['RandevuID'] ?></td>
                    <td><?= temizle($r['Ad']) ?></td>
                    <td><?= temizle($r['Soyad']) ?></td>
                    <td>Dr. <?= temizle($r['doktor_ad']) ?></td>
                    <td><?= temizle($r['doktor_soyad']) ?></td>
                    <td class="soluk"><?= temizle($r['BolumAdi']) ?></td>
                    <td class="soluk"><?= tarihFormat($r['RandevuTarihi'], 'd.m.Y H:i') ?></td>
                    <td><span class="etiket <?= $renk ?>"><?= temizle($r['Durum']) ?></span></td>
                    <td style="white-space:nowrap;">
                        <a href="?duzenle=<?= $r['RandevuID'] ?>" class="btn btn-gri btn-kucuk">Düzenle</a>
                        <a href="?sil=<?= $r['RandevuID'] ?>"
                           class="btn btn-kirmizi btn-kucuk"
                           onclick="return confirm('Randevu silinsin mi?')">Sil</a>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once '../includes/footer.php'; ?>