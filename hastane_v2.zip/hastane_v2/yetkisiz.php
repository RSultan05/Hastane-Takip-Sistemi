<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Yetkisiz Erişim</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500&family=Syne:wght@700&display=swap" rel="stylesheet">
    <style>
        body { font-family:'DM Sans',sans-serif; background:#0f172a; color:#f8fafc; min-height:100vh; display:flex; align-items:center; justify-content:center; text-align:center; }
        .kutu { max-width: 400px; }
        h1 { font-family:'Syne',sans-serif; font-size:28px; color:#ef4444; margin-bottom:10px; }
        p  { color:#64748b; margin-bottom:20px; font-size:14px; }
        a  { background:#2563eb; color:white; padding:10px 22px; border-radius:7px; text-decoration:none; font-size:13px; }
        a:hover { background:#3b82f6; }
    </style>
</head>
<body>
    <div class="kutu">
        <h1>⛔ Yetkisiz Erişim</h1>
        <p>Bu sayfaya erişim yetkiniz bulunmuyor.</p>
        <a href="/hastane_v2/login.php">← Giriş Sayfasına Dön</a>
    </div>
</body>
</html>
