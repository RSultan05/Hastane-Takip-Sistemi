<?php
// =============================================
// ÇIKIŞ İŞLEMİ
// =============================================
session_start();
session_destroy();
header("Location: /hastane_v2/login.php");
exit;
?>
